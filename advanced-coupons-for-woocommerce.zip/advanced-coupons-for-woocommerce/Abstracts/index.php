<?php /* Silence is Golden */
