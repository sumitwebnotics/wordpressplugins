<?php
namespace ACFWP\Models\REST_API;

use Automattic\WooCommerce\StoreApi\StoreApi;
use Automattic\WooCommerce\StoreApi\Schemas\ExtendSchema;
use Automattic\WooCommerce\StoreApi\Schemas\V1\CartSchema;

/**
 * WooCommerce Extend Store API for Cart Endpoint.
 *
 * @since 3.5.7
 */
class Store_API_Extend_Endpoint {
    /**
     * Stores Rest Extending instance.
     *
     * @since 3.5.7
     * @var ExtendSchema
     */
    private static $extend;

    /**
     * Plugin Identifier.
     *
     * @since 3.5.7
     * @var string
     */
    const IDENTIFIER = 'acfwp_block';

    /**
     * Bootstraps the class and hooks required data.
     *
     * @since 3.5.7
     * @access public
     */
    public static function init() {
        self::$extend = StoreApi::container()->get( ExtendSchema::class );
        self::extend_store();
    }

    /**
     * Registers the actual data into each endpoint.
     * - To see available endpoints to extend please go to : https://github.com/woocommerce/woocommerce-blocks/blob/trunk/docs/third-party-developers/extensibility/rest-api/available-endpoints-to-extend.md
     *
     * @since 3.5.7
     * @access public
     */
    public static function extend_store() {
        // Register into `cart`.
        if ( is_callable( array( self::$extend, 'register_endpoint_data' ) ) ) {
            self::$extend->register_endpoint_data(
                array(
                    'endpoint'      => CartSchema::IDENTIFIER,
                    'namespace'     => self::IDENTIFIER,
                    'data_callback' => array( 'ACFWP\Models\REST_API\Store_API_Extend_Endpoint', 'extend_data' ),
                    'schema_type'   => ARRAY_A,
                )
            );
        }
    }

    /**
     * Extend endpoint data.
     * - This data will be available in Redux Data Store `cartData.acfwp_block.extension`.
     * - To learn more you can visit : https://github.com/woocommerce/woocommerce-blocks/blob/trunk/docs/third-party-developers/extensibility/rest-api/extend-rest-api-add-data.md
     *
     * @since 3.5.7
     * @access public
     *
     * @return array $item_data Registered data or empty array if condition is not satisfied.
     */
    public static function extend_data() {
        return array(
            'coupons' => \ACFWP()->Helper_Functions->get_applied_coupon_data(),
        );
    }
}
