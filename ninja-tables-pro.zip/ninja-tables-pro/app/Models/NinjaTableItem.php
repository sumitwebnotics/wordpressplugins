<?php

namespace NinjaTablesPro\App\Models;

class NinjaTableItem extends Model
{
    protected $primaryKey = 'id';
    protected $table = 'ninja_table_items';
}
