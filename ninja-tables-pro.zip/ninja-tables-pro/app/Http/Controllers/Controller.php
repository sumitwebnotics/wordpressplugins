<?php

namespace NinjaTablesPro\App\Http\Controllers;

use NinjaTables\App\Http\Controllers\Controller as BaseController;

abstract class Controller extends BaseController
{
    // 
}
