<?php
/**
 * SBI_New_User.
 *
 * Not used in the pro version
 *
 * @since 5.9
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class SBI_New_User {
	/**
	 * Get notification data.
	 *
	 * @since 5.9
	 *
	 * @return array
	 */
	public function get() {
		return array();
	}
}
