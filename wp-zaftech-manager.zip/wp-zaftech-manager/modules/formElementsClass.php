<?php
if( !class_exists('formElementsClassSVN') ){
	class formElementsClassSVN{
		
		var  $type;
		var  $settings;
		var  $content;
	 
		function __construct( $type, $parameters, $value ){
	 
			$this->type = $type;
			$this->parameters = $parameters;

			// array empty patch
			$default_array = [
				'class' => '',
				'id' => '',
				'value' => '',
				'default' => '',
				'width' => '',
				'title' => '',
				'sub_title' => '',
				'sub_text' => '',
				'rows' => '',
				'name' => '',
				'href' => '',
				'style' => '',
				'upload_text' => '',
				'placeholder' => '',
			];	
			$this->parameters = array_merge( $default_array, $this->parameters );
			$this->value = $value;
			$this->generate_result_block();
 
		}
		function generate_result_block(){
			global $post;

			$out = '';
			switch( $this->type ){
				
				case "plugin_installer":
					$wzm_client_mode = get_option('wzm_client_mode');

					$out .= '
					<input type="hidden" id="wzm_client_mode" value="'.esc_html( $wzm_client_mode ).'" />
					<div class="'.( $this->parameters['width'] ? $this->parameters['width'] : 'col-12' ).'">
					<div class="zaf_block_cont container1">
						<div class="row zaftech_head">
							<div class="col-4 zaf_request">
							<a href="https://zaftech.org/request-plugin-or-theme" target="_blank"><i class="fa fa-paper-plane"></i>Request Plugin/Theme</a>
							</div>
							<div class="col-4 zaftech_head_text">
								ZAF TECH
							</div>
							<div class="col-4 zaf_account">
							<a href="https://zaftech.org/my-account" target="_blank"><i class="fa fa-user-circle" aria-hidden="true"></i>My Account</a>
							</div>
						</div>
					<div class="border_block ">
						<div class="row parent_filter_block '.( $wzm_client_mode == 'on' ? ' d-none ' : '' ).'">
							<button type="button" class="btn btn-clear  btn-sm " id="make_filter" data-checked="'.__('Check Installed Plugins/Themes For Update', 'wsa').'" data-unchecked="'.__('Show All Plugins/Themes', 'wsa').'" >'.__('Check Installed Plugins/Themes For Update', 'wsa').'</button>
						</div>


						<div class="row mb-3">
							<div class="col-12 zaftech_subtitle text-center">
								Welcome to Zaftech Plugin Manager
							</div>
						</div>';

				 
						$out .= '
						<div class="row mb-3 '.( $wzm_client_mode == 'on' ? ' d-none ' : '' ).'">
							<div class="col-12 input-group-sm  text-center">
								<input type="text" class="form-control mb-3" id="search_term" placeholder="'.__('Search', 'wsa').'">
							</div>
							<div class="col-12 text-center mb-3">
								<button type="submit" class="btn btn-search btn-sm w_15px" id="make_search_button">
									<span class="spinner-border spinner-border-sm d-none" role="status" aria-hidden="true"></span>
									'.__('Search', 'wsa').'
									</button>
								<button type="submit" class="btn btn-clear  btn-sm w_15px" id="make_clear" >'.__('Clear', 'wsa').'</button>
								
								<input type="hidden" id="make_filtered_search" value="0" />
							</div>
							<div class="col-12 text-center mb-3 update_message_new" style="display:none;">
							'.__('For the plugins or themes downloaded from zaftech plugin Manager or Zaftech Website, an "Update" button will appear once there is any update available.', 'wsa').'
							</div>
							 
						</div>';
					 

						$out .= '
						<div class="form-group">  
							<table class="table bg-white main_plugins_table">
							<thead>
								<tr>
									<th scope="col">'.__('Plugins/Themes', 'wsa').'</th>
									<th scope="col" class="text-center">'.__('Category', 'wsa').'</th>
									<th scope="col" class="text-center">'.__('Installed', 'wsa').'</th>
									<th scope="col" class="text-center">'.__('Current Version', 'wsa').'</th>
									<th scope="col" class="text-center">'.__('Latest Version Available', 'wsa').'</th>
									<th scope="col" class="text-center">'.__('Active', 'wsa').'</th>
									<th scope="col" class="text-center">'.__('Size', 'wsa').'</th>
									<th scope="col" class="text-center">'.__('Options', 'wsa').'</th>
								</tr>
							</thead>
							<tbody>';
							
							$object = new svnApiProcessing();
							$object->per_page = ITEM_NUMBER;
							$object->page = 1;
							$out .= $object->get_table_rows(); 
							$out .= '
							</tbody>
							</table> 
							
						  </div>';

						  if( $object->total > $object->per_page )
						  $out .= '
						  <div class="row mt-3 mb-4 load_more_container">
						 	<div class="col-12 text-center">
							 	<button type="button" class="btn btn-search btn-sm load_more">Load More</button>
								 <input type="hidden" id="current_page" value="'.$object->page.'" />
							 </div> 
						  </div>';
						  
						  $out .= '
					</div>

						  </div>
					</div>';	
				break;
				case "shortcode":
					$out .= '<div class="'.( $this->parameters['width'] ? $this->parameters['width'] : 'col-12' ).'">
						<div class="form-group">  
							<label class="control-label" for="'.$this->parameters['id'].'">'.$this->parameters['title'].'</label>  
							
							<input type="text" readonly class="form-control input-xlarge"   
							value="['.$this->parameters['name'].' id=\''.$post->ID.'\']"
							
							>  
							  <p class="help-block">'.$this->parameters['sub_text'].'</p>  
							
						  </div> 
					</div>';	
				break;
				
				case "sheet_picker":
					$out .= '
					<div class="row">
						<div class="col-6">
							<div class="form-group">  
					 
							  <input type="text"  class="form-control '.$this->parameters['class'].'"  name="'.$this->parameters['name'].'" id="'.$this->parameters['id'].'" placeholder="'.$this->parameters['placeholder'].'" value="'.( $this->value && $this->value != '' ? esc_html( stripslashes( $this->value ) ) : $this->parameters['default'] ).'">  
							  <p class="help-block">'.$this->parameters['sub_text'].'</p>  
							
							</div> 
							
							<div class="form-group">  
					 
							  <input type="text"  class="form-control '.$this->parameters['class'].'"  name="'.$this->parameters['name'].'" id="'.$this->parameters['id'].'" placeholder="Recipients Email">  
							  <p class="help-block">'.$this->parameters['sub_text'].'</p>  
							
							</div>
						</div> 
					</div>
						';
				break;
				case "separator":
					$out .= '
					<div class="'.( $this->parameters['width'] ? $this->parameters['width'] : 'col-12' ).'">
						<div class="lead">'.$this->parameters['title'].'</div> 
					</div>
						';
				break;
				
				case "text":
						$out .= '
					<div class="'.( $this->parameters['width'] ? $this->parameters['width'] : 'col-12' ).'">
						<div class="form-group">  
							<label class="control-label" for="'.$this->parameters['id'].'">'.$this->parameters['title'].'</label>  
							
							  <input type="text"  class="form-control '.$this->parameters['class'].'"  name="'.$this->parameters['name'].'" id="'.$this->parameters['id'].'" placeholder="'.$this->parameters['placeholder'].'" value="'.( $this->value && $this->value != '' ? esc_html( stripslashes( $this->value ) ) : $this->parameters['default'] ).'">  
							  <p class="help-block">'.$this->parameters['sub_text'].'</p>  
							
						  </div> 
					</div>
						';
						case "password":
							$out .= '
						<div class="'.( $this->parameters['width'] ? $this->parameters['width'] : 'col-12' ).'">
							<div class="form-group">  
								<label class="control-label" for="'.$this->parameters['id'].'">'.$this->parameters['title'].'</label>  
								
								  <input type="password" required class="form-control '.$this->parameters['class'].'"  name="'.$this->parameters['name'].'" id="'.$this->parameters['id'].'" placeholder="'.$this->parameters['placeholder'].'" >  
								  <p class="help-block">'.$this->parameters['sub_text'].'</p>  
								
							  </div> 
						</div>
							';
							/**
							 value="'.( $this->value && $this->value != '' ? esc_html( stripslashes( $this->value ) ) : $this->parameters['default'] ).'"
							 * 
							 */
				break;
				case "button":
						$out .= '
					<div class="'.( $this->parameters['width'] ? $this->parameters['width'] : 'col-12' ).'">
						<div class="form-group">  
							<label class="control-label" for="">&nbsp;</label>  
							
							  <a class="'.( $this->parameters['class'] ? $this->parameters['class'] : 'btn btn-success' ).'" href="'.$this->parameters['href'].'"   >'.$this->parameters['title'].'</a>  
							  
							
						</div> 
					</div>
						';
				break;
				case "select":
						$out .= '
					<div class="'.( $this->parameters['width'] ? $this->parameters['width'] : 'col-12' ).'">
						<div class="form-group">  
							<label class="control-label" for="'.$this->parameters['id'].'">'.$this->parameters['title'].'</label>  
							 
							  <select  style="'.$this->parameters['style'].'" class="form-control '.$this->parameters['class'].'" name="'.$this->parameters['name'].'" id="'.$this->parameters['id'].'">' ; 
							  if( count( $this->parameters['value'] ) > 0 )
							  foreach( $this->parameters['value'] as $k => $v ){
								  if( $this->value && $this->value != '' ){
									$out .= '<option value="'.$k.'" '.( $this->value  == $k ? ' selected ' : ' ' ).' >'.$v.'</option> ';
								  }else{
									$out .= '<option value="'.$k.'" '.( $this->parameters['default']  == $k ? ' selected ' : ' ' ).' >'.$v.'</option> ';
								  }
							  }
						$out .= '		
							  </select>  
							  <p class="help-block">'.$this->parameters['sub_text'].'</p> 
							</div>  
					</div>	 
						';
				break;
				case "checkbox":
						$out .= '
					<div class="'.( $this->parameters['width'] ? $this->parameters['width'] : 'col-12' ).'">
						<div class="form-group">  
							<label class="control-label" for="'.$this->parameters['id'].'">'.$this->parameters['title'].'</label>  
						
							  <label class="checkbox">  
								<input  class="'.$this->parameters['class'].'" type="checkbox" name="'.$this->parameters['name'].'" id="'.$this->parameters['id'].'" value="on" '.( $this->value == 'on' ? ' checked ' : '' ).' > &nbsp; 
								'.$this->parameters['text'].'  
								<p class="help-block">'.$this->parameters['sub_text'].'</p> 
							  </label>  
							 
						  </div>  
					</div>
						';
				break;
				case "radio":
						$out .= '
					<div class="'.( $this->parameters['width'] ? $this->parameters['width'] : 'col-12' ).'">
						<div class="form-group">  
							<label class="control-label" for="'.$this->parameters['id'].'">'.$this->parameters['title'].'</label>';
								foreach( $this->parameters['value'] as $k => $v ){
									$out .= '
									<label class="radio">  
										<input  class="'.$this->parameters['class'].'" type="radio" name="'.$this->parameters['name'].'" id="'.$this->parameters['id'].'" value="'.$k.'" '.( $this->value == $k ? ' checked ' : '' ).' >&nbsp;  
										'.$v.'  
										<p class="help-block">'.$this->parameters['sub_text'].'</p> 
									  </label> ';
								}
							$out .= '
							
						  </div>  
					</div>
						';
				break;
				case "textarea":
						$out .= '
					<div class="'.( $this->parameters['width'] ? $this->parameters['width'] : 'col-12' ).'">
						<div class="form-group">  
							<label class="control-label" for="'.$this->parameters['id'].'">'.$this->parameters['title'].'</label>  
						
							  <textarea style="'.$this->parameters['style'].'" class="form-control '.$this->parameters['class'].'" name="'.$this->parameters['name'].'" id="'.$this->parameters['id'].'" rows="'.$this->parameters['rows'].'">'.( $this->parameters['name'] && $this->parameters['name'] != '' ?  esc_html( stripslashes( $this->value ) ) : $this->parameters['default'] ).'</textarea>  
							  <p class="help-block">'.$this->parameters['sub_text'].'</p> 
						 
						  </div> 
					</div>
						';
				break;
				case "multiselect":
						$out .= '
					<div class="'.( $this->parameters['width'] ? $this->parameters['width'] : 'col-12' ).'">
						<div class="form-group">  
							<label class="control-label" for="'.$this->parameters['id'].'">'.$this->parameters['title'].'</label>  
							 
							  <select  multiple="multiple" style="'.$this->parameters['style'].'" class="form-control '.$this->parameters['class'].'" name="'.$this->parameters['name'].'[]" id="'.$this->parameters['id'].'">' ; 
							  foreach( $this->parameters['value'] as $k => $v ){
								  $out .= '<option value="'.$k.'" '.( @in_array( $k, $this->value )   ? ' selected ' : ' ' ).' >'.$v.'</option> ';
							  }
						$out .= '		
							  </select>  
							  <p class="help-block">'.$this->parameters['sub_text'].'</p> 
							 
						  </div>  
					</div>
						';
				break;
				case "wide_editor":
					$out .= '
					<div class="'.( $this->parameters['width'] ? $this->parameters['width'] : 'col-12' ).'">
						<div class="form-group">  
							<label class="control-label" for="input01">'.$this->parameters['title'].'</label>
							<div class="form-control1">
							';  
							
							ob_start();
							wp_editor( $this->value, $this->parameters['name'] );
							$editor_contents = ob_get_clean();	
						 
							$out .= $editor_contents;  
						$out .= '
							</div>
						  </div> 
					</div>';	 
					 
				break;
				case "file":
						$out .= '
					<div class="'.( $this->parameters['width'] ? $this->parameters['width'] : 'col-12' ).'">
						<div class="form-group">  
							<label class="control-label" for="'.$this->parameters['id'].'">'.$this->parameters['title'].'</label>  
				 
							<input type="file" class="form-control-file '.$this->parameters['class'].'" name="'.$this->parameters['name'].''.( $this->parameters['multi'] ? '[]' : '' ).'" id="'.$this->parameters['id'].'" '.( $this->parameters['multi'] ? ' multiple ' : '' ).' >
							  
							  <p class="help-block">'.$this->parameters['sub_text'].'</p> 
						 
						  </div>
					</div>
						';
				break;
				case "mediafile_single":
					$attach_url = wp_get_attachment_url( $this->value );
					
					$out .= '
					<div class="'.( $this->parameters['width'] ? $this->parameters['width'] : 'col-12' ).'">
						<div class="form-group media_upload_block">  
						<label class="control-label" for="input01">'.$this->parameters['title'].'</label>  
						 
						  <input type="hidden" class="form-control input-xlarge mediafile_single item_id" name="'.$this->parameters['name'].'" id="'.$this->parameters['name'].'" value="'.$this->value.'"> 
						  
						
						  <input type="button" class="btn btn-success upload_file" data-single="1" value="'.$this->parameters['upload_text'].'" />
						  <div class="image_preview">'.( $attach_url ?  $attach_url  : '' ).'</div>
						</div> 
					</div>';	
					break;
					
					case "save":
				 
					$out .= '
					<div class="'.( $this->parameters['width'] ? $this->parameters['width'] : 'col-12' ).'">
						<div class="form-actions">  
							<button type="submit" class="btn btn-primary">'.$this->parameters['title'].'</button>  
						</div> 
					</div>
					';	
					break;
					case "link":
				 
					$out .= '
					<div class="'.( $this->parameters['width'] ? $this->parameters['width'] : 'col-12' ).'">
						<div class="form-actions">  
							<a href="'.$this->parameters['href'].'" class="'.$this->parameters['class'].'">'.$this->parameters['title'].'</a>  
						</div> 
					</div>
					';	
					break;
					
					case "text_out":
				 
					$out .= '
					<div class="'.( $this->parameters['title'] ? $this->parameters['title'] : 'col-12' ).'">
						'.$this->parameters['class'].'
					</div>
					';	
					break;
			}
			$this->content = $out;
		 
		}
		public function  get_code(){
			return $this->content;
		}
	}
}
 
?>