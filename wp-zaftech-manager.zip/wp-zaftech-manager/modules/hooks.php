<?php 

// add admin bar menu
add_action( 'admin_bar_menu', 'wpse_form_in_admin_bar' );
function wpse_form_in_admin_bar() {
    global $wp_admin_bar;

    $wp_admin_bar->add_menu( array(
        'id' => 'wpse-form-in-admin-bar',
        'parent' => 'top-secondary',
        'title' => wsa_title_block() //'<form><input type="text" /><input type="submit" /> </form>'
    ));
}

// add admin bar menu
function wsa_title_block(){
	return '<div class="custom_plugin_box"><a href="'.admin_url( 'admin.php?page=wsa_main_api' ).'">Plugins Install</a></div>';
}




// class to work with api
class svnApiProcessing{
    var $plugins_data;
    var $api_key;
    var $per_page;
    var $page;
    var $total;
    var $search;
    var $is_update;

    var $is_filtered_search;
    function __construct(){
        $settings = get_option('wsa__options');
		$api_key = $settings['api_key'];

        $this->api_key = $api_key;

        $this->is_filtered_search = 0;
    }

    function set_filtered_search(){
        $this->is_filtered_search = 1;
    }

    // recursive delete
    function rrmdir($dir) { 
        if (is_dir($dir)) { 
        $objects = scandir($dir);
        foreach ($objects as $object) { 
            if ($object != "." && $object != "..") { 
            if (is_dir($dir. DIRECTORY_SEPARATOR .$object) && !is_link($dir."/".$object))
                $this->rrmdir($dir. DIRECTORY_SEPARATOR .$object);
            else
                unlink($dir. DIRECTORY_SEPARATOR .$object); 
            } 
        }
        rmdir($dir); 
        } 
    }

    function get_existed_slugs(){
     
        wp_clean_plugins_cache();
            wp_clean_themes_cache();
            $plugins_list = get_plugins();
            $themes_list = get_themes();

        $all_existed_slugs = [];
        foreach( $plugins_list as $_code => $_value ){
            $tmp = explode('/', $_code);
            $all_existed_slugs[] = $tmp[0];
        }

        foreach( $themes_list as $theme_name => $_value ){
            $all_existed_slugs[] = sanitize_title( $_value->get_stylesheet() );
        }

        return $all_existed_slugs;
    }

    function get_plugins_list(  ){
        $feed_url = 'https://zaftech.org/wp-json/wsas/v1/plugins_list/';
       // $feed_url = 'http://localhost/wordpress/wp-json/wsas/v1/plugins_list/';

        if( $this->search && $this->search != '' ){
            $result = wp_remote_post( $feed_url.'?api_key='.$this->api_key.'&per_page='.$this->per_page.'&page='.$this->page.'&s_term='.$this->search.'&filtered='.$this->is_filtered_search.'&site_url='.$this->get_site_main_part(), 
            [   
                'timeout' => 360,
                'body' => [ 
                    'slugs' => json_encode(  $this->get_existed_slugs() ) 
                    ] 

            ] 
            );
        }else{
            $result = wp_remote_post( $feed_url.'?api_key='.$this->api_key.'&per_page='.$this->per_page.'&page='.$this->page.'&filtered='.$this->is_filtered_search.'&site_url='.$this->get_site_main_part(), 
            [ 
                'timeout' => 360,
                'body' => [ 
                    'slugs' => json_encode(  $this->get_existed_slugs() ) 
                    ] 
            ] 
            );
        }
        
        if( is_wp_error( $result ) ){
            return [ 'result' => 'error', 'message' => $result->get_error_message() ];
        }else{
            $result_body = json_decode( $result['body'], true );
            //var_dump( $result_body );
            if( $result_body['result'] == 'success' ){

                $this->total = $result_body['total'];
                $this->page = $result_body['page'];

                $this->plugins_data = $result_body['list'];

                // make urls cache
                $all_cached_urls = get_option('cached_urls');
        
                foreach( $result_body['list'] as $s_plugin ){
                    $all_cached_urls[$s_plugin['slug']] = $s_plugin;
                }
                update_option( 'cached_urls', $all_cached_urls );

                return [ 'result' => 'success', 'list' => $result_body['list'] ];
            }else{
                return [ 'result' => 'error', 'message' => $result_body['message'] ];
            }
            
        }

    }
    public function get_table_rows( $single_row_slug = false, $is_inner  = false  ){

        
        $data_array = $this->get_plugins_list(  );

        if( $data_array['result'] == 'success' || $is_inner ){
            $row_data = '';
            wp_clean_plugins_cache();
            wp_clean_themes_cache();
            $plugins_list = get_plugins();
            $themes_list = get_themes();
 
            
            $all_existed_plugins_versions = [];
            $all_existed_plugin_slugs = [];
            foreach( $plugins_list as $_code => $_value ){
                $tmp = explode('/', $_code);
    
                $all_existed_plugin_slugs[] = $tmp[0];
                $tmp_version = $_value['Version'];
                if( substr( $tmp_version, 0, 1 ) == '.' ){
                    $tmp_version = ltrim( trim( $tmp_version ), '.');
                }
                $all_existed_plugins_versions[ $tmp[0] ] = $tmp_version;
            }


            $active_plugins = get_option('active_plugins');
            $all_active_plugin_slugs = [];
            foreach( $active_plugins as $_code  ){
                $tmp = explode('/', $_code);
                $all_active_plugin_slugs[] = $tmp[0];
    
            }

            // all existed themes
            $all_existed_themes_slugs = [];
            $all_existed_themes_versions = [];
            foreach( $themes_list as $theme_name => $_value ){
                $all_existed_themes_slugs[] = sanitize_title( $_value->get_stylesheet() );

                $tmp_version = $_value['Version'];
                if( substr( $tmp_version, 0, 1 ) == '.' ){
                    $tmp_version = ltrim($tmp_version, '.');
                }

                $all_existed_themes_versions[  sanitize_title( $_value->get_stylesheet() ) ] = $tmp_version;
            }
    
          
 
            $active_theme_slug =  wp_get_theme()->get_stylesheet();
          
            // bushfix slug
            if( $is_inner ){
                $data_array['list'] = get_option('cached_urls');
            }

            
        
            foreach( $data_array['list'] as $s_plugin ){
    
          
                $item_type = $s_plugin['type'];

            if( $item_type == 'plugin' ){
           
                // return single row
                if(  $is_inner  ){
                    if( $single_row_slug != $s_plugin['slug'] ){ continue; }
                }

                // make search
                /*
                if( $search_term && $search_term != '' ){
                    if( substr_count( strtolower( $s_plugin['name'] ), strtolower( $search_term ) ) == 0 ){ continue; }
                }
                */

                $is_plugin_installed = 0;
                $is_plugin_active = 0;
                $item_current_version = ' - ';
                // if instgalled
               
                if( in_array( $s_plugin['slug'], $all_existed_plugin_slugs ) ){
                    $is_plugin_installed = 1;
                    $installed_mark = '<i class="fa fa-check text-installed" aria-hidden="true"></i>';
                }else{
                    //$installed_mark = '<i class="fa fa-times  text-danger" aria-hidden="true"></i>';
                    $installed_mark = ' - ';
                }
                
                // if active
             
                if( in_array( $s_plugin['slug'], $all_active_plugin_slugs ) ){
                    $is_plugin_active = 1;
                    $active_mark = '<i class="fa fa-check text-active" aria-hidden="true"></i>';
                }else{
                    //$active_mark = '<i class="fa fa-times  text-danger" aria-hidden="true"></i>';
                    $active_mark = ' - ';
                }
    
                // check if versions are same
                $require_update = 0;
                if( isset( $all_existed_plugins_versions[$s_plugin['slug']] ) ){
                    if( $s_plugin['version'] != $all_existed_plugins_versions[$s_plugin['slug']] ){
                        $require_update = 1;
                    }
                }
                
    
                // process current version
                if( isset( $all_existed_plugins_versions[$s_plugin['slug']] ) ){
                    if( $all_existed_plugins_versions[$s_plugin['slug']] ){
                        $item_current_version = $all_existed_plugins_versions[$s_plugin['slug']];
                    }
                }
                
    
                // actions row
                // not installed
                if( $is_plugin_installed == 0 ){
                    $action_row = '
                    <ul>
                        <li><a href="#" class="btn btn-download btn-sm install_plugin" data-id="'.$s_plugin['slug'].'">'.__('Download','wsa').'</a></li>
                    </ul>
                    ';
                }else{
                    //plugin installed but not active
                    if( $is_plugin_active == 0 ){
                        if( $require_update == 0 ){
                            $action_row = '
                            <ul >
                                <li><a href="#" class="btn btn-activate btn-sm activate_plugin" data-id="'.$s_plugin['slug'].'">'.__('Activate','wsa').'</a></li>
                            </ul>
                            ';
                        }else{
                            $action_row = '
                            <ul>
                                <li><a href="#" class="btn btn-activate btn-sm  activate_plugin" data-id="'.$s_plugin['slug'].'" >'.__('Activate','wsa').'</a></li>
                                <li><a href="#" class="btn btn-update btn-sm  install_plugin" data-is_update="1" data-id="'.$s_plugin['slug'].'" >'.__('Update','wsa').'</a></li>
                            </ul>
                            ';
                        }
                    }else{
                        if( $require_update == 0 ){
                            $action_row = '';
                        }else{
                            $action_row = '
                            <ul>
                                <li><a href="#" class="btn btn-update btn-sm install_plugin" data-is_update="1" data-id="'.$s_plugin['slug'].'">'.__('Update','wsa').'</a></li>
                            </ul>
                            ';
                        }
                    }
                    
                    
                }
            }

            if( $item_type == 'theme' ){
               
                // return single row
                if(  $single_row_slug  ){
                    if( $single_row_slug != $s_plugin['slug'] ){ continue; }
                }

                // make search
                if( isset( $search_term ) ){
                    if( $search_term && $search_term != '' ){
                        if( substr_count( strtolower( $s_plugin['name'] ), strtolower( $search_term ) ) == 0 ){ continue; }
                    }
                }
                

                $is_theme_installed = 0;
                $is_theme_active = 0;
                $item_current_version = ' - ';
                // if instgalled
               
    
                if( in_array( $s_plugin['slug'], $all_existed_themes_slugs ) ){
                    $is_theme_installed = 1;
                    $installed_mark = '<i class="fa fa-check text-installed" aria-hidden="true"></i>';
                }else{
                    //$installed_mark = '<i class="fa fa-times  text-danger" aria-hidden="true"></i>';
                    $installed_mark = ' - ';
                }
    
                // if active
            
                if( $s_plugin['slug'] == sanitize_title( $active_theme_slug ) ){
                    $is_theme_active = 1;
                    $active_mark = '<i class="fa fa-check text-active" aria-hidden="true"></i>';
                }else{
                    //$active_mark = '<i class="fa fa-times  text-danger" aria-hidden="true"></i>';
                    $active_mark =  ' - ';
                }
      
                // check if versions are same
                $require_update = 0;
                if( isset( $all_existed_themes_versions[$s_plugin['slug']] ) ){
                    if( $s_plugin['version'] != $all_existed_themes_versions[$s_plugin['slug']] ){
                        $require_update = 1;
                    }
                }
                
               
                // process current version
                if( isset($all_existed_themes_versions[$s_plugin['slug']]) ){
                    if( $all_existed_themes_versions[$s_plugin['slug']] ){
                        $item_current_version = $all_existed_themes_versions[$s_plugin['slug']];
                    }
                }
                
                
    
                // actions row
                // not installed
                if( $is_theme_installed == 0 ){
                    $action_row = '
                    <ul>
                        <li><a href="#" class="btn btn-download btn-sm install_plugin" data-id="'.$s_plugin['slug'].'">'.__('Download','wsa').'</a></li>
                    </ul>
                    ';
                }else{
                    //plugin installed but not active
                    if( $is_theme_active == 0 ){
                        if( $require_update == 0 ){
                            $action_row = '
                            <ul >
                                <li><a href="#" class="btn btn-activate btn-sm activate_theme" data-id="'.$s_plugin['slug'].'">'.__('Activate','wsa').'</a></li>
                            </ul>
                            ';
                        }else{
                            $action_row = '
                            <ul>
                                <li><a href="#" class="btn btn-activate btn-sm activate_theme" data-id="'.$s_plugin['slug'].'" >'.__('Activate','wsa').'</a></li>
                                <li><a href="#" class="btn btn-update btn-sm install_plugin"  data-is_update="1" data-id="'.$s_plugin['slug'].'" >'.__('Update','wsa').'</a></li>
                            </ul>
                            ';
                        }
                    }else{
                        if( $require_update == 0 ){
                            $action_row = '';
                        }else{
                            $action_row = '
                            <ul>
                                <li><a href="#" class="btn btn-update btn-sm install_plugin"  data-is_update="1" data-id="'.$s_plugin['slug'].'">'.__('Update','wsa').'</a></li>
                            </ul>
                            ';
                        }
                    }
                    
                    
                }
            }
    
                
    
                $row_data .= '
                <tr>
                    <th scope="row" class="title_text"><a href="'.$s_plugin['link'].'" target="_blank">'.$s_plugin['name'].'</a></th>
                    <td class="text-center">'.$s_plugin['category'].'</td>
                    <td class="text-center">'.$installed_mark.'</td>
                    <td class="text-center">'.ltrim(  trim( $item_current_version ), '.').'</td>
                    <td class="text-center">'.ltrim( trim($s_plugin['version'] ), '.').'</td>
                    <td class="text-center">'.$active_mark.'</td>
                    <td  class="text-center" >'.$this->formatSizeUnits($s_plugin['size']).'</td>
                    <td class="plugin_actions text-center">'.$action_row.'</td>
                </tr>';
            }
        }

        if( $data_array['result'] == 'error' ){
            $row_data .= '
            <tr>
                <th scope="row" colspan="7"><div class="alert alert-warning">'.$data_array['message'].'</div></th>
  
            </tr>';
        }

        
        return $row_data;
    }
    
    function formatSizeUnits($bytes)
        {
            if ($bytes >= 1073741824)
            {
                $bytes = number_format($bytes / 1073741824, 2) . ' GB';
            }
            elseif ($bytes >= 1048576)
            {
                $bytes = number_format($bytes / 1048576, 2) . ' MB';
            }
            elseif ($bytes >= 1024)
            {
                $bytes = number_format($bytes / 1024, 2) . ' KB';
            }
            elseif ($bytes > 1)
            {
                $bytes = $bytes . ' bytes';
            }
            elseif ($bytes == 1)
            {
                $bytes = $bytes . ' byte';
            }
            else
            {
                $bytes = '0 bytes';
            }

            return $bytes;
    }

    // plugin download and replace
    function install_plugin( $slug ){
        //$this->get_plugins_list();

        $all_cached_urls = get_option('cached_urls');
  
        foreach( $all_cached_urls as $plugin_slug => $s_plugin ){
            
            if(  $plugin_slug == $slug ){
            
                $item_type = $s_plugin['type'];
                

                // process download
                $url = $s_plugin['download_url'];
      
                $download_url = 'https://zaftech.org?file_name='.urlencode( $url ).'&api_key='.$this->api_key.'&site_url='.$this->get_site_main_part();
                if( $this->is_update == '1' ){
                    $download_url = 'https://zaftech.org?file_name='.urlencode( $url ).'&api_key='.$this->api_key.'&site_url='.$this->get_site_main_part().'&is_update=1';
                }
              
                $file_content = wp_remote_get( $download_url, array(
                    'timeout'     => 360,
                    'httpversion' => '1.1',
                ) );
                $filename = basename( $url );
                if( is_wp_error( $file_content ) ){
                    // process downmload error
                    return [ 'result' => 'error', 'message' => __('URL request error', 'wsa') ];
                }else{
                    // process downloading
                    $upload_dir = wp_upload_dir();

                    $tmp_dir = $upload_dir['basedir'].'/tmp_manager';

                    if( !is_dir( $tmp_dir ) ){
                        $res = wp_mkdir_p( $tmp_dir );
                        if( !$res ){
                            return [ 'result' => 'error', 'message' => __('Can\'t create download dir', 'wsa') ];
                        } 
                    }

                    $file_tmp_name = $upload_dir['basedir'].'/tmp_manager/'.$filename;
                    $res = file_put_contents( $file_tmp_name, $file_content['body'] );

 

                    // verify if file downloaded 
                    if( !$res ){
                        return [ 'result' => 'error', 'message' => __('Can\'t download file', 'wsa') ];
                    }else{
                        // file downloaded lets unzip to plugins dir

                        if( $item_type == 'plugin' ){
                            // remove original plugin dir
                            $current_folder_path = WP_PLUGIN_DIR.'/'.$slug;
                            $install_folder_path = WP_PLUGIN_DIR.'/';
                            $this->rrmdir( $current_folder_path );
                        }
                        if( $item_type == 'theme' ){
                            // remove original plugin dir
                            $current_folder_path = WP_CONTENT_DIR . '/themes/'.$slug;
                            $install_folder_path = WP_CONTENT_DIR . '/themes/';
                            $this->rrmdir( $current_folder_path );
                        }
                        

                        if( !class_exists( 'ZipArchive' ) ){
                            return [ 'result' => 'error', 'message' => __('You need to have Zip Archive activated on your server', 'wsa') ];
                        }

                        $zip = new ZipArchive();
                        $result = $zip->open( $file_tmp_name );
                      
                        if ( $result === TRUE) 
                        {
                            $folderName = trim($zip->getNameIndex(0), '/');
                            $zip->extractTo( $install_folder_path );
                            $zip->close();
                            
                            // patch for __MACOSX
                            $this->rrmdir( $install_folder_path.'__MACOSX' );

                            $message = $this->get_table_rows( $slug, true );
                            return [ 'result' => 'success', 'message' => $message ];
                        } 
                        else 
                        {
                            return [ 'result' => 'error', 'message' => __('Can\'t unzip file', 'wsa') ];
                        }

                        
                    }
                    
                    
                }
            }
        }
        
    
    }

    // activate plugin
    function activate_plugin( $slug ){
        
        $is_activated = 0;
        wp_clean_plugins_cache();
        $plugins_list = get_plugins();
        foreach( $plugins_list as $plugin_file => $s_plugin ){
            $dir_name = explode( '/', $plugin_file );
            if( $dir_name[0] == $slug ){


                

                activate_plugin( $plugin_file );
                $is_activated = 1;
            }
        }
        if( $is_activated == 0 ){
            return [ 'result' => 'error', 'message' => __('Can\'t activate plugin', 'wsa') ];
        }else{
            $message = $this->get_table_rows( $slug, true );
            return [ 'result' => 'success', 'message' => $message ];
        }
    }

    // activate plugin
    function activate_theme( $slug ){

        wp_clean_themes_cache();
        // activate slug
        $themes_list = get_themes();
        foreach( $themes_list as $s_theme_name => $value ){
            if( sanitize_title($s_theme_name) == $slug ){
                $activite_title = $value->stylesheet;
            }
        }
     
        switch_theme( $activite_title );
        //if( $is_activated == 0 ){
        //    return [ 'result' => 'error', 'message' => __('Can\'t activate plugin', 'wsa') ];
        //}else{
            $message = $this->get_table_rows( $slug, true );
            return [ 'result' => 'success', 'message' => $message ];
       // }
    }

    /**
     * get site main url
     */
    function get_site_main_part(){
        $url = get_option('home');
        $url = str_replace( 'https://', '', $url );
        $url = str_replace( 'http://', '', $url );
        $url = str_replace( '/', '', $url );
        return $url;
    }
    
}
 

/** remove notices functionality */

add_action('init', function(){

    if( 1 == 1 ){
        add_filter( 'admin_notices', function(){
            ob_start();
        }, 1, 1 );
        add_filter( 'admin_notices', function(){
            $page = ob_get_contents();
            ob_end_clean();
        
         
            include_once( 'simple_html_dom.php');
            $html = str_get_html( '<html><body>'.$page.'</body></html>' );
  
            foreach($html->find('div') as $element){
                $this_classes = $element->class;

                if( $element->parent()->tag == 'body' ){
                    if( substr_count( $this_classes, 'travelpayouts-chunk' ) > 0 || substr_count( $this_classes, 'travelpayouts-notice' ) > 0 ){               
                        echo  $element->outertext;
                        continue;
                    }
                    if( substr_count( $this_classes, 'dokan' ) > 0   ){      
                        echo  $element->outertext;
                        continue;
                    }
                    $srs_text =  $element->innertext;
              
                
                    if( substr_count( strtolower( $srs_text ), 'serial' ) == 0 && substr_count( strtolower( $srs_text ), 'licens' ) == 0 && substr_count( strtolower( $srs_text ), 'update' ) == 0 && substr_count( strtolower( $srs_text ), 'register' ) == 0
                
                    ){
                        echo $element->outertext;
                    }

                }
          
               
             
            }
            foreach($html->find('script') as $element){
                echo $element->outertext;
            }
            foreach($html->find('style') as $element){
                echo $element->outertext;
            }
               
        
        }, 1000000, 1 );
    }


    /**
     * process client mode
     */
    if( isset( $_POST['client_mode'] ) ){
        if(  wp_verify_nonce($_POST['wsa_config_save_settings_field'], 'wsa_config_save_settings_action') ){
            $current_client_mode = get_option('wzm_client_mode');
            if( !$current_client_mode ){
                // not set
                if( $_POST['client_mode'] == 'on' ){
                    update_option('wzm_client_mode', 'on');
                }
                if( $_POST['client_mode'] == 'off' ){
                    update_option('wzm_client_mode', 'off');
                }

            }else{
                if( $current_client_mode == 'on' && $_POST['client_mode'] == 'off'  ){
                 
                }
                if( $_POST['client_mode'] == 'on' ){
                    update_option('wzm_client_mode', 'on');
                }
                if( $_POST['client_mode'] == 'off' ){
                    update_option('wzm_client_mode', 'off');
                }

            }
        }
    }

});


add_action('admin_footer', function(){
    $settings = get_option('wsa__options');		
    if( $settings['api_key'] && $settings['api_key'] != '' )    
        echo '<input id="ztapk" value="'.md5( $settings['api_key'] ).'" type="hidden" />';
});





?>