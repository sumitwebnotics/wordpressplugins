<?php 
 
add_action('wp_ajax_make_data_search', 'wsa_make_data_search');
add_action('wp_ajax_nopriv_make_data_search', 'wsa_make_data_search');

function wsa_make_data_search(){
	global $current_user, $wpdb;
	if( check_ajax_referer( 'ajax_call_nonce', 'security') ){
		
		echo json_encode([ 'result' => 'success', 'html' => '' ]);
		
	}
	die();
}


add_action('wp_ajax_download_plugin', 'wsa_download_plugin');
add_action('wp_ajax_nopriv_download_plugin', 'wsa_download_plugin');

function wsa_download_plugin(){
	global $current_user, $wpdb;
	if( check_ajax_referer( 'ajax_call_nonce', 'security') ){
		
		$slug = sanitize_text_field( $_POST['plugin_slug'] );
		$is_update = sanitize_text_field( $_POST['is_update'] );

		$obj = new svnApiProcessing();
		$obj->is_update = $is_update;
		$result = $obj->install_plugin( $slug );
 
	 
		if( $result['result'] == 'success' ){
			echo json_encode([ 'result' => 'success', 'html' => $result['message'] ]);			
		}else{
			echo json_encode([ 'result' => 'error', 'message' => $result['message'] ]);
		}


		//echo json_encode([ 'result' => 'success', 'html' => '' ]);
		
	}
	die();
}

// activate plugin
add_action('wp_ajax_activate_plugin', 'wsa_activate_plugin');
add_action('wp_ajax_nopriv_activate_plugin', 'wsa_activate_plugin');

function wsa_activate_plugin(){
	global $current_user, $wpdb;
	if( check_ajax_referer( 'ajax_call_nonce', 'security') ){
		
		$slug = sanitize_text_field( $_POST['plugin_slug'] );

		$obj = new svnApiProcessing();
		$result = $obj->activate_plugin( $slug );
		
	 
		if( $result['result'] == 'success' ){
			echo json_encode([ 'result' => 'success', 'html' => $result['message'] ]);			
		}else{
			echo json_encode([ 'result' => 'error', 'message' => $result['message'] ]);
		}


		//echo json_encode([ 'result' => 'success', 'html' => '' ]);
		
	}
	die();
}

// activate theme
add_action('wp_ajax_activate_theme', 'wsa_activate_theme');
add_action('wp_ajax_nopriv_activate_theme', 'wsa_activate_theme');

function wsa_activate_theme(){
	global $current_user, $wpdb;
	if( check_ajax_referer( 'ajax_call_nonce', 'security') ){
		
		$slug = sanitize_text_field( $_POST['plugin_slug'] );

		$obj = new svnApiProcessing();
		$result = $obj->activate_theme( $slug );
		
	 
		if( $result['result'] == 'success' ){
			echo json_encode([ 'result' => 'success', 'html' => $result['message'] ]);			
		}else{
			echo json_encode([ 'result' => 'error', 'message' => $result['message'] ]);
		}


		//echo json_encode([ 'result' => 'success', 'html' => '' ]);
		
	}
	die();
}


// make search
add_action('wp_ajax_make_search', 'wsa_make_search');
add_action('wp_ajax_nopriv_make_search', 'wsa_make_search');

function wsa_make_search(){
	global $current_user, $wpdb;
	if( check_ajax_referer( 'ajax_call_nonce', 'security') ){
		
		$search_term = sanitize_text_field( $_POST['search_term'] );
		$make_filtered_search = (int)$_POST['make_filtered_search'];

		$obj = new svnApiProcessing();
		$obj->per_page = ITEM_NUMBER;

		/**
		 * Filtered search patch
		 */

		if( $make_filtered_search == 1 ){
			$obj->set_filtered_search();
			$obj->per_page = 500;
		
		}

		
		$obj->page = 1;
		$obj->search = $search_term;
		$row_text = $obj->get_table_rows( false  );
		
	 
		echo json_encode([ 'result' => 'success', 'html' => $row_text ]);			
		 


		//echo json_encode([ 'result' => 'success', 'html' => '' ]);
		
	}
	die();
}
// load_more
add_action('wp_ajax_load_more', 'wsa_load_more');
add_action('wp_ajax_nopriv_load_more', 'wsa_load_more');

function wsa_load_more(){
	global $current_user, $wpdb;
	if( check_ajax_referer( 'ajax_call_nonce', 'security') ){
		
		$page = (int)$_POST['current_page'];
		$search_term = sanitize_text_field( $_POST['search_term'] );

		$page++;
 
		$object = new svnApiProcessing();
		$object->per_page = ITEM_NUMBER;
		$object->page = $page;
		if( $search_term && $search_term != '' ){
			$object->search = $search_term;
		}
		$out = $object->get_table_rows();
		 
		echo json_encode([ 'result' => 'success', 'page' => $object->page, 'html' => $out ]);			
		 


		//echo json_encode([ 'result' => 'success', 'html' => '' ]);
		
	}
	die();
}



?>