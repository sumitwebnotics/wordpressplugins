jQuery(document).ready(function($){

/**
 * client mode
 */
if( $('#wzm_client_mode').val() == 'on' ){
	$('.parent_filter_block').hide();
	setTimeout(function(){
		$('#make_filter').click();	
	}, 1000);
	
}

/*
client mode change
*/
$('body').on('change', '#client_mode', function(){

	if( $(this).val() == 'off' ){
 
		var initial_api_key = $('#ztapk').val();
 
		var  person = prompt("Please enter API key" );

		if( !person || person == null || person == 'null' ){
			$(this).val( 'on' );
		}

		var passhash = md5(person);
 
		if( initial_api_key != passhash ){
			alert('Sorry, you entered wrong API key');
			$(this).val( 'on' );
		}

	
		
	}
})
 
// make clear
$('body').on( 'click', '#make_clear', function( e ){
	e.preventDefault();
	$('#search_term').val('');
 
	$('#make_search_button').click();
})
// make clear
$('body').on( 'click', '#make_filter', function( e ){
	e.preventDefault();

	$(this).toggleClass('is_clicked');
	if( $(this).hasClass('is_clicked')  ){

		$(this).html( $(this).attr('data-unchecked') );
		$('.update_message_new').fadeIn();
		$('#search_term').val('');
		$('#make_filtered_search').val('1');
		$('#make_search_button').click();

	}else{
		$(this).html( $(this).attr('data-checked') );
		$('.update_message_new').fadeOut();
		$('#search_term').val('');
		$('#make_filtered_search').val('0');
		$('#make_search_button').click();
	}


	
	
})

// install plugin
$('body').on( 'click', '.install_plugin', function( e ){
	e.preventDefault();
		// verify email
		var row_pointer = $(this).parents('tr');
		var data = {
			plugin_slug  : $(this).attr('data-id'),
			is_update  : $(this).attr('data-is_update'),
			security  : wsa_local_data.nonce,
			action : 'download_plugin'
		}
		 
		jQuery.ajax({url: wsa_local_data.ajaxurl,
				type: 'POST',
				data: data,            
				beforeSend: function(msg){
						jQuery('body').append('<div class="big_loader"></div>');
					},
					success: function(msg){
						
						
						console.log( msg );
						
						jQuery('.big_loader').replaceWith('');
						
						var obj = jQuery.parseJSON( msg );
						
						console.log( obj );
				 
						if( obj.result == 'success' ){
							console.log( 'success' );
							row_pointer.replaceWith( obj.html );
						}else{
							alert( obj.message );
							console.log( obj.message );
						}
						 
					} , 
					error:  function(msg) {
						console.log( msg );
					}          
			});
	 
	})
// install plugin
$('body').on( 'click', '.load_more', function( e ){
	e.preventDefault();
		// verify email

		var data = {
			search_term  : $('#search_term').val(),
			current_page  : $('#current_page').val(),
			security  : wsa_local_data.nonce,
			action : 'load_more'
		}
		jQuery.ajax({url: wsa_local_data.ajaxurl,
				type: 'POST',
				data: data,            
				beforeSend: function(msg){
						jQuery('body').append('<div class="big_loader"></div>');
					},
					success: function(msg){
						
						
						console.log( msg );
						
						jQuery('.big_loader').replaceWith('');
						
						var obj = jQuery.parseJSON( msg );
						
						console.log( obj );
				 
						if( obj.result == 'success' ){
							console.log( 'success' );
							$('.main_plugins_table tbody').append( obj.html );
							$('#current_page').val( obj.page );
							if( obj.html == '' ){
								$('.load_more_container').fadeOut();
							}
					 
						}else{
							console.log( obj.message );
						}
						 
					} , 
					error:  function(msg) {
						console.log( msg );
					}          
			});
	 
	})


	// activate plugin
$('body').on( 'click', '.activate_plugin', function( e ){
	e.preventDefault();
		// verify email
		var row_pointer = $(this).parents('tr');
		var data = {
			plugin_slug  : $(this).attr('data-id'),
			security  : wsa_local_data.nonce,
			action : 'activate_plugin'
		}
		jQuery.ajax({url: wsa_local_data.ajaxurl,
				type: 'POST',
				data: data,            
				beforeSend: function(msg){
						jQuery('body').append('<div class="big_loader"></div>');
					},
					success: function(msg){
						
						
						console.log( msg );
						
						jQuery('.big_loader').replaceWith('');
						
						var obj = jQuery.parseJSON( msg );
						
						console.log( obj );
				 
						if( obj.result == 'success' ){
							console.log( 'success' );
							row_pointer.replaceWith( obj.html );
						}else{
							console.log( obj.message );
						}
						 
					} , 
					error:  function(msg) {
						console.log( msg );
					}          
			});
	 
	})

	


	// activate plugin
$('body').on( 'click', '.activate_theme', function( e ){
	e.preventDefault();
		// verify email
		var row_pointer = $(this).parents('tr');
		var data = {
			plugin_slug  : $(this).attr('data-id'),
			security  : wsa_local_data.nonce,
			action : 'activate_theme'
		}
		jQuery.ajax({url: wsa_local_data.ajaxurl,
				type: 'POST',
				data: data,            
				beforeSend: function(msg){
						jQuery('body').append('<div class="big_loader"></div>');
					},
					success: function(msg){
						
						
						console.log( msg );
						
						jQuery('.big_loader').replaceWith('');
						
						var obj = jQuery.parseJSON( msg );
						
						console.log( obj );
				 
						if( obj.result == 'success' ){
							console.log( 'success' );
							row_pointer.replaceWith( obj.html );
						}else{
							console.log( obj.message );
						}
						 
					} , 
					error:  function(msg) {
						console.log( msg );
					}          
			});
	 
	})


	// search functionality
$('body').on( 'click', '#make_search_button', function( e ){
	e.preventDefault();
		// verify email
	 
		var data = {
			make_filtered_search: $('#make_filtered_search').val(),
			search_term  : $('#search_term').val(),
			security  : wsa_local_data.nonce,
			action : 'make_search'
		}
	
		jQuery.ajax({url: wsa_local_data.ajaxurl,
				type: 'POST',
				data: data,            
				beforeSend: function(msg){
						jQuery('body').append('<div class="big_loader"></div>');
					},
					success: function(msg){
						
						
						console.log( msg );
						
						jQuery('.big_loader').replaceWith('');
						
						var obj = jQuery.parseJSON( msg );
						
						console.log( obj );
				 
						if( obj.result == 'success' ){
							console.log( 'success' );
							$('.main_plugins_table tbody').html( obj.html );

							if( $('#make_filtered_search').val() == '1' ){
								$('.load_more_container').hide();
							}else{
								$('.load_more_container').show();
							}
							$('#make_filtered_search').val('0');

							console.log( 'obj.html' );
							if( obj.html == '' ){
								$('.load_more_container').hide();
								$('.main_plugins_table tbody').html( '<tr><td colspan="7"><div class="alert alert-warning text-center">Can\'t find what you are looking for ? <a href="https://zaftech.org/help-me-find" target="_blank">Click here</a></div></td></tr>' );
								
							}


						}else{
							console.log( obj.message );
						}
						 
					} , 
					error:  function(msg) {
						console.log( msg );
					}          
			});
	 
	})
	
	 
	
});
