<?php 

if( !class_exists('vooSettingsClassSVN') ){
class vooSettingsClassSVN{
	/* V1.0.1 */
	var $setttings_parameters;
	var $settings_prefix;
	var $message;
	
	function __construct( $prefix ){
		$this->setttings_prefix = $prefix;	
		
		if( isset($_POST[$this->setttings_prefix.'save_settings_field']) ){
			if(  wp_verify_nonce($_POST[$this->setttings_prefix.'save_settings_field'], $this->setttings_prefix.'save_settings_action') ){
				$options = array();
				foreach( $_POST as $key=>$value ){
					$options[$key] = $value ;
				}
				update_option( $this->setttings_prefix.'_options', $options );
				
				$this->message = '<div class="alert alert-success">'.__('Settings saved', $this->setttings_prefix ).'</div>';
				
			}
		}
		
		
	}
	
	function get_setting( $setting_name ){
		$inner_option = get_option( $this->setttings_prefix.'_options');
		return $inner_option[$setting_name];
	}
	
	function create_menu( $parameters ){
		$this->setttings_parameters = $parameters;		
			
		add_action('admin_menu', array( $this, 'add_menu_item') );
		
	}
	
	 
	
	
	function add_menu_item(){

		$default_array = [
			'type' => '',
			'parent_slug' => '',
			'form_title' => '',
			'is_form' => '',
			'page_title' => '',
			'menu_title' => '',
			'capability' => '',
			'menu_slug' => '',
			'icon' => ''
		];	
		$this->setttings_parameters = array_merge( $default_array, $this->setttings_parameters );
		
		foreach( $this->setttings_parameters as $single_option ){
			if( !isset( $single_option['type'] ) ){ continue; }
			if( $single_option['type'] == 'menu' ){
				add_menu_page(  			 
				$single_option['page_title'], 
				$single_option['menu_title'], 
				$single_option['capability'], 
				$this->setttings_prefix.$single_option['menu_slug'], 
				array( $this, 'show_settings' ),
				$single_option['icon']
				);
			}
			if( $single_option['type'] == 'submenu' ){
				add_submenu_page(  
				$single_option['parent_slug'],  
				$single_option['page_title'], 
				$single_option['menu_title'], 
				$single_option['capability'], 
				$this->setttings_prefix.$single_option['menu_slug'], 
				array( $this, 'show_settings' ) 
				);
			}
			if( $single_option['type'] == 'option' ){
				add_options_page(  				  
				$single_option['page_title'], 
				$single_option['menu_title'], 
				$single_option['capability'], 
				$this->setttings_prefix.$single_option['menu_slug'], 
				array( $this, 'show_settings' ) 
				);
			}
		}
		 
	}
	
	function show_settings(){
		// hide output if its parent menu
		if( count( $this->setttings_parameters[0]['parameters'] ) == 0 ){ return false; }
		
		?>
		<div class="wrap tw-bs4">
		
		
		
		<h2><?php echo $this->setttings_parameters[0]['form_title']; ?></h2>
		<hr/>
		<?php 
			echo $this->message;
		?>
		
		<?php if( $this->setttings_parameters[0]['is_form'] ): ?>
			<form class="form-horizontal" method="post" action="">
		<?php endif; ?>

		<?php 
		wp_nonce_field( $this->setttings_prefix.'save_settings_action', $this->setttings_prefix.'save_settings_field'  );  
		$config = get_option( $this->setttings_prefix.'_options'); 
		 
		?>  
		<fieldset>

			<?php 
			foreach( $this->setttings_parameters as $single_page ){	
				if( !isset($single_page['parameters']) ){ continue; }
				foreach( $single_page['parameters'] as $key=>$value ){	

					$interface_element_value =  '';
					if( isset($value['name']) ){
						if( isset( $config[$value['name']] ) ){
							$interface_element_value =  $config[$value['name']];
						}
					}
					
					
					$interface_element = new formElementsClassSVN( $value['type'], $value, $interface_element_value );
					echo $interface_element->get_code();	 
				}
			}
			?>
		</fieldset>  
		
		<?php if( $this->setttings_parameters[0]['is_form'] ): ?>
		</form>
		<?php endif; ?>

		</div>
		<?php
	}
}	
}	
 
	
	
add_Action('init',  function (){

	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) 
		return;
	
	if ( defined('DOING_AJAX') && DOING_AJAX ) {
		return;
	}

	$locale = 'wsa';
	
	$config_big = 
	array(
		array(
			'type' => 'menu',
		 
			'form_title' => __('Zaftech', $locale),
			'is_form' => true,
			'page_title' => __('Zaftech', $locale),
			'menu_title' => __('Zaftech', $locale),
			'capability' => 'edit_published_posts',
			'menu_slug' => 'main_api',
			'icon' => '',
			'parameters' => array(
	 
				array(
					'type' => 'plugin_installer',
					'title' => __('API Key',$locale),
					'name' => 'api_key',
					'sub_text' => __('', $locale),
					'style' => ' height:300px; ',
					'id' => '',
					'class' => ''
				),
 
				
				 
			)
		)
	); 
	global $settings;

	$settings = new vooSettingsClassSVN( 'wsa_' ); 
	$settings->create_menu(  $config_big   );
	

	
	global $settings;
	$config_big = 
	array(
		array(
			'type' => 'submenu',
			'parent_slug' => 'wsa_main_api',
			'form_title' => __('Zaftech API', $locale),
			'is_form' => true,
			'page_title' => __('Zaftech API', $locale),
			'menu_title' => __('API', $locale),
			'capability' => 'edit_published_posts',
			'menu_slug' => 'install_data',
			'parameters' => array(
	 
				array(
					'type' => 'password',
					'title' => __('API Key',$locale),
					'name' => 'api_key',
					'sub_text' => __('Please, enter API data. If you dont have it, you can find it <a target="_blank" href="https://zaftech.org/my-account/api-key/">here</a>', $locale),
					'style' => ' height:300px; ',
					'id' => '',
					'class' => ''
				),
				array(
					'type' => 'save',
					'title' => __('Save', $locale),
				),
				
				 
			)
		)
	); 
	$settings = new vooSettingsClassSVN( 'wsa_' ); 
	$settings->create_menu(  $config_big   );



	$config_big = 
	array(
		array(
			'type' => 'submenu',
			'parent_slug' => 'wsa_main_api',
			'form_title' => __('Settings', $locale),
			'is_form' => true,
			'page_title' => __('Settings', $locale),
			'menu_title' => __('Settings', $locale),
			'capability' => 'edit_published_posts',
			'menu_slug' => 'extra_settings',
			'parameters' => array(
	 
		 
				array(
					'type' => 'select',
					'title' => __('Client Mode', $locale),
					'name' => 'client_mode',
					'sub_text' => __('', $locale),
					'value' => [ 
						'off' => __('Off', $locale),
						'on' => __('On', $locale),
					],
					'style' => '   ',
					'id' => 'client_mode',
					'class' => ''
				),
				 
				array(
					'type' => 'save',
					'title' => __('Save', $locale),
				),
				
				 
			)
		)
	); 
	$settings = new vooSettingsClassSVN( 'wsa_config_' ); 
	$settings->create_menu(  $config_big   );
} );
	
 

?>