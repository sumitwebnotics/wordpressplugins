<?php

namespace Yoast\WP\SEO\Premium\Exceptions\Remote_Request;

use Exception;

/**
 * Class Remote_Request_Exception
 */
abstract class Remote_Request_Exception extends Exception {

}
